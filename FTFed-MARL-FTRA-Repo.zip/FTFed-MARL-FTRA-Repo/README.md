# FTFed-MARL + FTRA Simulation Code (Demo)

This repository contains reproducible demo scripts to generate the simulation CSVs used in the paper and to produce basic figures.

## Structure
- `src/run_simulator.py` : Generates CSV datasets (50 rounds) for scenarios with 100, 300, 500 nodes.
- `src/plot_results.py` : Loads CSVs and generates sample figures (Fig.4 and Fig.5 variants).
- `src/utils.py` : Helper functions for data generation.
- `data/` : Output CSVs (created by running run_simulator.py).
- `figures/` : Output PNGs produced by plot_results.py.
- `README.md` : This file.

## Usage (example)
```bash
cd src
python run_simulator.py --outdir ../data --rounds 50 --seed 42
python plot_results.py --data ../data --out ../figures
```

## Notes
- This code provides a deterministic demo generator and plotting utility to reproduce the CSVs and sample figures for manuscript preparation. Replace the generator with your actual simulator/RL code when available.
- Requirements: Python 3.8+, numpy, pandas, matplotlib.
