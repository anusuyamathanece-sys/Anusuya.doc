import pandas as pd
import matplotlib.pyplot as plt
import argparse
from pathlib import Path

def style_plot():
    plt.rcParams.update({'figure.figsize': (12,8)})
    plt.rcParams.update({'font.size': 14})

def plot_metrics(data_dir, outdir):
    style_plot()
    # load
    df100 = pd.read_csv(Path(data_dir)/'ftra_metrics_100.csv')
    df300 = pd.read_csv(Path(data_dir)/'ftra_metrics_300.csv')
    df500 = pd.read_csv(Path(data_dir)/'ftra_metrics_500.csv')

    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)

    # Fig 4a: Alive vs Dead (stacked plot)
    plt.figure()
    plt.plot(df100['Round'], df100['Alive'], label='Alive (100)', marker='o', linewidth=2)
    plt.plot(df100['Round'], df100['Dead'], label='Dead (100)', marker='x', linewidth=2)
    plt.title('Alive vs Dead Nodes (100 nodes)')
    plt.xlabel('Round'); plt.ylabel('Count'); plt.grid(True); plt.legend(fontsize=12)
    plt.tight_layout()
    plt.savefig(outdir/'fig4a_alive_dead_100.png', dpi=200)
    plt.close()

    # Fig 4c: ESI (all scenarios)
    plt.figure()
    plt.plot(df100['Round'], df100['ESI'], label='100 Nodes', marker='o', linewidth=2)
    plt.plot(df300['Round'], df300['ESI'], label='300 Nodes', marker='s', linewidth=2)
    plt.plot(df500['Round'], df500['ESI'], label='500 Nodes', marker='^', linewidth=2)
    plt.title('Energy Sustainability Index vs Rounds')
    plt.xlabel('Round'); plt.ylabel('ESI'); plt.ylim(0,1.05); plt.grid(True); plt.legend(fontsize=12)
    plt.tight_layout()
    plt.savefig(outdir/'fig4c_esi_all.png', dpi=200)
    plt.close()

    # Fig 5: Charging requests vs rounds (all)
    plt.figure()
    plt.plot(df100['Round'], df100['Requesting'], label='100 Nodes', marker='o', linewidth=2)
    plt.plot(df300['Round'], df300['Requesting'], label='300 Nodes', marker='s', linewidth=2)
    plt.plot(df500['Round'], df500['Requesting'], label='500 Nodes', marker='^', linewidth=2)
    plt.title('Charging Requests vs Rounds')
    plt.xlabel('Round'); plt.ylabel('Requests'); plt.grid(True); plt.legend(fontsize=12)
    plt.tight_layout()
    plt.savefig(outdir/'fig5_requests.png', dpi=200)
    plt.close()

    print('Saved sample figures to', outdir)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, default='../data', help='data folder')
    parser.add_argument('--out', type=str, default='../figures', help='output figure folder')
    args = parser.parse_args()
    plot_metrics(args.data, args.out)
