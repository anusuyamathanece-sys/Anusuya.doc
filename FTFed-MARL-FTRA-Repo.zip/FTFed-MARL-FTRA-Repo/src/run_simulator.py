import argparse
from pathlib import Path
from utils import generate_round_data

def main():
    parser = argparse.ArgumentParser(description='Generate FTFed-MARL simulation CSVs (demo).')
    parser.add_argument('--outdir', type=str, default='../data', help='output folder for CSVs')
    parser.add_argument('--rounds', type=int, default=50, help='number of simulation rounds')
    parser.add_argument('--seed', type=int, default=42, help='random seed')
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    scenarios = [100, 300, 500]
    for n in scenarios:
        df = generate_round_data(total_nodes=n, rounds=args.rounds, seed=args.seed, fail_period=10)
        fname = outdir / f"ftra_metrics_{n}.csv"
        df.to_csv(fname, index=False)
        print('Wrote', fname)

if __name__ == '__main__':
    main()
