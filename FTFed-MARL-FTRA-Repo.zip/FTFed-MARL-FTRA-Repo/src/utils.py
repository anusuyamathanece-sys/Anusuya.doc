import numpy as np
import pandas as pd

def generate_round_data(total_nodes, rounds=50, seed=42, fail_period=10):
    np.random.seed(seed)
    Alive = []
    Dead = []
    Requesting = []
    ChargingEvents = []
    ESI = []
    MWC_failures = []
    ReassignedTasks = []
    TotalEnergyConsumed = []
    alive = total_nodes
    total_energy = 0.0
    for r in range(rounds):
        # simple deterministic decay + noise to emulate behavior
        decay = int(total_nodes * 0.015)  # nodes dying per round approx
        alive = max(alive - decay, 0)
        dead = total_nodes - alive
        req = int(total_nodes * 0.10 + (r % 7) * 5)
        chg = max(0, int(total_nodes * 0.08 + (r % 5) * 4 - (r%3)))
        esi = alive / total_nodes
        # failures and reassignments
        fail = 1 if (r % fail_period == 0 and r!=0) else 0
        reassign = int((r % 4) * 3) if fail else 0
        # energy consumption growth
        total_energy += r * 80 + total_nodes * 0.25
        Alive.append(alive)
        Dead.append(dead)
        Requesting.append(req)
        ChargingEvents.append(chg)
        ESI.append(round(esi, 4))
        MWC_failures.append(fail)
        ReassignedTasks.append(reassign)
        TotalEnergyConsumed.append(round(total_energy,3))
    df = pd.DataFrame({
        "Round": list(range(1, rounds+1)),
        "Alive": Alive,
        "Dead": Dead,
        "Requesting": Requesting,
        "ChargingEvents": ChargingEvents,
        "ESI": ESI,
        "MWC_failures": MWC_failures,
        "ReassignedTasks": ReassignedTasks,
        "TotalEnergyConsumed": TotalEnergyConsumed
    })
    return df

